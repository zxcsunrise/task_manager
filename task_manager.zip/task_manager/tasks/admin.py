from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, Task

class CustomUserAdmin(UserAdmin):
    list_display = ('email', 'first_name', 'role', 'is_staff', 'is_active', 'date_joined')
    list_filter = ('role', 'is_staff', 'is_active', 'date_joined')
    search_fields = ('email', 'first_name')
    ordering = ('-date_joined',)
    
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Персональная информация', {'fields': ('first_name', 'last_name')}),
        ('Роли и права', {'fields': ('role', 'is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Важные даты', {'fields': ('last_login', 'date_joined')}),
    )
    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'first_name', 'password1', 'password2', 'role', 'is_staff', 'is_active')}
        ),
    )

class TaskAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'status', 'created_at', 'get_user_role')
    list_filter = ('status', 'created_at', 'user__role')
    search_fields = ('title', 'description', 'user__email', 'user__first_name')
    readonly_fields = ('created_at',)
    date_hierarchy = 'created_at'
    
    def get_user_role(self, obj):
        return obj.user.get_role_display()
    get_user_role.short_description = 'Роль пользователя'
    
    fieldsets = (
        ('Основная информация', {
            'fields': ('title', 'description', 'status')
        }),
        ('Пользователь', {
            'fields': ('user',)
        }),
        ('Даты', {
            'fields': ('created_at',),
            'classes': ('collapse',)
        }),
    )

# Регистрируем модели
admin.site.register(CustomUser, CustomUserAdmin)
admin.site.register(Task, TaskAdmin)