from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator
from .models import Task, CustomUser
from .forms import CustomUserCreationForm, TaskForm, UserRoleForm
from .decorators import admin_required

def register_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Регистрация прошла успешно!')
            return redirect('task_list')
    else:
        form = CustomUserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

def login_view(request):
    from django.contrib.auth import authenticate, login
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, username=email, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f'Добро пожаловать, {user.first_name}!')
            return redirect('task_list')
        else:
            messages.error(request, 'Неверный email или пароль')
    return render(request, 'registration/login.html')

def logout_view(request):
    logout(request)
    messages.success(request, 'Вы успешно вышли из системы')
    return redirect('login')

@login_required
def task_list(request):
    if request.user.is_administrator():
        tasks = Task.objects.all().order_by('-created_at')
    else:
        tasks = Task.objects.filter(user=request.user).order_by('-created_at')
    
    # Фильтрация
    status_filter = request.GET.get('status')
    if status_filter:
        tasks = tasks.filter(status=status_filter)
    
    # Поиск
    search_query = request.GET.get('search')
    if search_query:
        tasks = tasks.filter(title__icontains=search_query)
    
    # Пагинация
    paginator = Paginator(tasks, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'tasks/task_list.html', {
        'page_obj': page_obj,
        'status_filter': status_filter,
        'search_query': search_query or ''
    })

@login_required
def task_create(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.user = request.user
            task.save()
            messages.success(request, 'Задача успешно создана!')
            return redirect('task_list')
    else:
        form = TaskForm()
    return render(request, 'tasks/task_form.html', {'form': form, 'title': 'Создать задачу'})

@login_required
def task_edit(request, pk):
    task = get_object_or_404(Task, pk=pk)
    
    # Проверка прав доступа
    if not request.user.is_administrator() and task.user != request.user:
        messages.error(request, 'У вас нет прав для редактирования этой задачи')
        return redirect('task_list')
    
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            messages.success(request, 'Задача успешно обновлена!')
            return redirect('task_list')
    else:
        form = TaskForm(instance=task)
    
    return render(request, 'tasks/task_form.html', {'form': form, 'title': 'Редактировать задачу'})

@login_required
@admin_required
def task_delete(request, pk):
    task = get_object_or_404(Task, pk=pk)
    if request.method == 'POST':
        task.delete()
        messages.success(request, 'Задача успешно удалена!')
        return redirect('task_list')
    return render(request, 'tasks/task_confirm_delete.html', {'task': task})

@login_required
@admin_required
def user_list(request):
    users = CustomUser.objects.all().order_by('-date_joined')
    return render(request, 'tasks/user_list.html', {'users': users})

@login_required
@admin_required
def user_role_edit(request, pk):
    user = get_object_or_404(CustomUser, pk=pk)
    if request.method == 'POST':
        form = UserRoleForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, f'Роль пользователя {user.email} успешно обновлена!')
            return redirect('user_list')
    else:
        form = UserRoleForm(instance=user)
    return render(request, 'tasks/user_role_form.html', {'form': form, 'user': user})